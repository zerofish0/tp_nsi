###[Previsions meteo]###
## zerofish0           #
########################
## importations
import csv
import math
import requests
import datetime
import logging
import io
## Constantes
RELEVE = dict()
COMMUNES = dict()
STATIONS = dict()
communes_filename = "communes_gps.csv"
stations_filename = "postesSynop.txt"

logger = logging.getLogger(__name__)
FORMAT = '%(asctime)s %(message)s'
logging.basicConfig(level=logging.INFO,format = FORMAT)

## Fonctions
def extractCommunesData(communes_filename : str) -> dict :
    """Extrait les coordonées géographiques de toutes les communes de France"""
    logger.info("Traitement des données des communes")
    #ouvrir le fichier
    file = open(communes_filename,"r")
    reader = csv.DictReader(file,delimiter = ";")

    #récupérer toutes les données
    data0 = list()
    for ordered_dict in reader : data0.append(dict(ordered_dict))

    #récupérer uniquement le nom et les coordonées
    data1 = dict()
    for dictionnary in data0 :
        cache = dictionnary
        city = cache["nom_commune"].lower()
        coo = (cache["latitude"],cache["longitude"])
        data1[city] = coo
    return data1

def extractStationsData(stations_filename : str) -> dict :
    """renvoie le dictionnaire des stations"""
    logger.info("Traitement des données des stations")
    #ouvrir le fichier
    file = open(stations_filename,"r")
    reader = csv.DictReader(file,delimiter = ";")

    #récupérer toutes les données
    data0 = list()
    for ordered_dict in reader : data0.append(dict(ordered_dict))

    #récupérer uniquement le nom et les coordonées
    data1 = dict()
    for dictionnary in data0 :
        cache = dictionnary
        id_station = int(cache["ID"])
        coo = (cache["Latitude"],cache["Longitude"])
        name = cache["Nom"]
        data1[id_station] = [coo,name]
    return data1

def extractReleveData(csv_data : str) -> dict :
    """renvoie le releve de temperature par stations"""
    logger.info("Traitement des relevés météo")
    # Utiliser StringIO pour traiter la chaîne comme un fichier
    csv_file = io.StringIO(csv_data)

    # Lire avec csv.DictReader
    reader = csv.DictReader(csv_file, delimiter=';')

    # Créer un dictionnaire
    data_dict = {}

    # Parcours chaque ligne du fichier CSV
    for row in reader:
        numer_sta = row['numer_sta']  # Récupère la valeur de numer_sta
        temperature = row['t']  # Récupère la valeur de la température (colonne 't')

        # Ajouter à notre dictionnaire
        try :
            data_dict[int(numer_sta)] = float(temperature) - 273.15
        except : pass

    return data_dict


def synchronizeReleveAndStations(releve, stations) :
    logger.info("Synchronisation des tables de stations et du relevé")
    l1 = list(stations.keys())
    l2 = list(releve.keys())
    for cache2 in l1 :
        if not cache2 in l2 :
            del stations[cache2]
    return releve,stations

def getDistanceBetweenTwoPoints(lat1,lon1,lat2,lon2) -> float :
    """renvoie la distance en metres separant les deux points" (harvesine formule)"""
    logger.debug("Calcul de la distance entre deux points")
    #lat1,lon1 = *coo1
    #lat2,lon2 = *coo2
    earth_radius = 6371 #km

    haversine = lambda x : math.sin(x/2)**2

    #on convertit en radians
    rlat1, rlat2 = math.radians(float(lat1)), math.radians(float(lat2))
    rlon1, rlon2 = math.radians(float(lon1)), math.radians(float(lon2))

    #on applique la formule (https://fr.wikipedia.org/wiki/Formule_de_haversine)
    distance = 2 * earth_radius * math.asin(
        math.sqrt(
            haversine(rlat2-rlat1) +
            math.cos(rlat1) * math.cos(rlat2) * haversine(rlon2-rlon1)
        )
    )

    return round(distance,3)

def getCoefficientOfStation(distance_to_station : float) -> float :
    """Renvoie le coefficient de la station par rapport à sa distance de la ville recherchée"""
    logger.debug("Calculs des coefficiants des stations")
    return 1/(distance_to_station ** 2)

def getNearestStations(n : int, stations_coo : dict, city_coordinates : tuple) -> float :
    """renvoie les n plus proches stations des city_coordinates, en se basant su stations_coo"""
    logger.debug("Obtention des stations proches")
    stations = list(stations_coo.keys())
    data = dict()
    for station in stations :
        station_coordinates = stations_coo[station]
        d = getDistanceBetweenTwoPoints(*station_coordinates[0],*city_coordinates)
        data[station] = d
    nearest_stations = list()
    for _ in range(n) :
        near = min(stations, key = lambda x : data[x])
        nearest_stations.append(near)
        stations.remove(near)
    return nearest_stations

def getStationTemperatureAndCoefficient(distance : float,station_id : str,releve : dict) -> list :
    logger.debug("Obtention de la température et du coefficient de chaque station")
    return [releve[station_id],getCoefficientOfStation(distance)]

def calculateAverageTemperature(data : list) -> float :
    logger.debug("Calcul de la température moyenne")
    total = int()
    sum_ = int()
    for station in data :
        sum_ += station[0] * station[1]
        total += station[1]
    return (sum_/total)

def calculateAverageTemperatureOfACity(city : str, communes_dict : dict, releve_dict : dict, stations_dict : dict,n_stations = 3) -> float :
    logger.debug("Calcul de la température moyenne de la ville")
    city_coordinates = communes_dict[city.lower()]
    near_stations = getNearestStations(n_stations, stations_dict, city_coordinates)
    data = list()
    for station in near_stations :
        distance = getDistanceBetweenTwoPoints(*city_coordinates, *stations_dict[station][0])
        data.append(getStationTemperatureAndCoefficient(distance, station,releve_dict))
    avg_temp = calculateAverageTemperature(data)
    return avg_temp

def getCurrentTime() :
    """Renvoie le temps du jour de forme yyyymmddhh"""
    logger.debug("Calcul du temps actuel")
    now = datetime.datetime.now()
    ymd = now.strftime("%Y%m%d")
    hourint = 3 * ((int(now.strftime("%H"))-1)//3)
    h = "0" + str(hourint) if len(str(hourint))==1 else str(hourint)
    date = ymd+h
    return date

def getTemperatureOf(city : str) -> float :
    COMMUNES = extractCommunesData(communes_filename)
    STATIONS = extractStationsData(stations_filename)
    date = getCurrentTime()
    print(date)
    rep = requests.get(f"https://donneespubliques.meteofrance.fr/donnees_libres/Txt/Synop/synop.{date}.csv").text
    RELEVE = extractReleveData(rep)

    RELEVE,STATIONS = synchronizeReleveAndStations(RELEVE,STATIONS)
    return round(calculateAverageTemperatureOfACity(city,COMMUNES,RELEVE,STATIONS,3),2)
## Programme principal
if __name__ == "__main__" :
    in_ = str(input("Entrez le nom de la ville dont vous souhaiter connaitre la température : "))
    out_ = getTemperatureOf(in_)
    print(f"La température approximée de {in_} est {out_} °C")

































