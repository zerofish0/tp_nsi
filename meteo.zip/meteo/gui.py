import customtkinter
import meteo

customtkinter.set_appearance_mode("dark")

class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()
        self.title("Météo")
        self.grid_rowconfigure(0, weight=1)  # configure grid system
        self.grid_columnconfigure(0, weight=1)
        self.iconbitmap("weather0.ico")

        self.entry = customtkinter.CTkEntry(self, placeholder_text="Entrez une ville...")
        self.entry.grid(row=0, column=0,padx = 50,pady = 15)

        self.button = customtkinter.CTkButton(self, text="Charger !", command=self.load)
        self.button.grid(row = 1, column = 0,padx = 10,pady = 5)

        self.label = customtkinter.CTkLabel(self, text="Appuyez ↑", fg_color="transparent")
        self.label.grid(row = 2,column = 0,padx = 10,pady = 5)

    def load(self) :
        city = self.entry.get()
        try :
            data = meteo.getTemperatureOf(city)
        except :
            data = "NA"
        finally :
            self.label.configure(text = f"{data} °C")


app = App()
app.mainloop()
